import 'dart:async';
import 'dart:convert';

import 'package:aicha_media/aicha_media.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../models/shop_settings.dart';
import '../nav.dart';
import '../screens/admin/admin_orders_screen.dart';
import '../screens/chat_screen.dart';
import '../screens/order_detail_screen.dart';
import '../screens/team/team_chat_screen.dart';
import '../widgets/item_card.dart';
import 'db.dart';
import 'session.dart';

/// Message reçu quand l'application est fermée ou en arrière-plan.
/// Appel entrant : notification plein écran avec sonnerie (s'affiche aussi
/// sur l'écran verrouillé) qui ouvre l'application sur l'appel.
@pragma('vm:entry-point')
Future<void> firebaseBackgroundHandler(RemoteMessage m) async {
  if (m.data['type'] == 'incoming_call') {
    final name = (m.data['callerName'] ?? '').toString();
    try {
      // Secours : normalement déjà affiché par Android (CallPushReceiver).
      await AichaMedia.showIncomingCall(
        (m.data['callId'] ?? '').toString(),
        name,
        'Aïcha Services',
      );
    } catch (_) {}
  } else if (m.data['type'] == 'call_ended') {
    try {
      await AichaMedia.cancelIncomingCall();
    } catch (_) {}
  }
}

/// Envoi des notifications push via le serveur gratuit (Cloudflare Worker),
/// qui les transmet à Firebase Cloud Messaging.
/// Tant que l'adresse du serveur n'est pas renseignée dans
/// Gestion → Paramètres, rien n'est envoyé (l'appli fonctionne quand même).
class NotifyService {
  static String? _url;

  static void resetCache() => _url = null;

  static Future<String> _endpoint() async {
    if (_url != null) return _url!;
    try {
      final s = ShopSettings.fromDoc(await Db.settingsDoc.get());
      _url = s.pushEnabled ? s.notifyUrl : '';
    } catch (_) {
      _url = '';
    }
    return _url!;
  }

  static Future<bool> _post(Map<String, dynamic> body) async {
    try {
      final url = await _endpoint();
      if (url.isEmpty) return false;
      final token = await FirebaseAuth.instance.currentUser?.getIdToken();
      if (token == null) return false;
      final res = await http
          .post(
            Uri.parse(url),
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer $token',
            },
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 15));
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  /// Appel test vers ce téléphone (via le serveur) : 'ok', 'old' (serveur
  /// pas à jour) ou 'error'.
  static Future<String> testCall() async {
    try {
      final url = await _endpoint();
      if (url.isEmpty) return 'error';
      final token = await FirebaseAuth.instance.currentUser?.getIdToken();
      if (token == null) return 'error';
      // Pas d'attente de la réponse : le serveur patiente 8 s avant d'appeler.
      final res = await http
          .post(Uri.parse(url),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer $token',
              },
              body: jsonEncode({'action': 'test_call', 'check': true}))
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 400) return 'old';
      if (res.statusCode != 200) return 'error';
      await http
          .post(Uri.parse(url),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer $token',
              },
              body: jsonEncode({'action': 'test_call'}))
          .timeout(const Duration(seconds: 15));
      return 'ok';
    } catch (_) {
      return 'error';
    }
  }

  /// Réunion d'équipe : faire sonner les membres / arrêter la sonnerie.
  static void roomCall({required String roomId}) =>
      _post({'action': 'room_call', 'roomId': roomId});
  static void roomEnded({required String roomId}) =>
      _post({'action': 'room_ended', 'roomId': roomId});

  /// Discussion d'équipe actuellement à l'écran (pas de bandeau pour elle).
  static String openTeamChat = '';

  /// Message d'équipe : prévient les membres (ou toute l'équipe d'une boutique).
  static void team({
    required String chatId,
    required String shopId,
    required bool wholeShop,
    required List<String> uids,
    required String title,
    required String body,
  }) {
    final data = {'type': 'team', 'chatId': chatId, 'audience': 'staff', 'from': _me};
    if (wholeShop) {
      _post({
        'action': 'to_staff',
        'shopId': shopId,
        'title': title,
        'body': body,
        'data': data,
      });
      return;
    }
    for (final u in uids.take(30)) {
      _post({
        'action': 'to_user',
        'uid': u,
        'kind': 'messages',
        'title': title,
        'body': body,
        'data': data,
      });
    }
  }

  static Map<String, String> _strings(Map<String, dynamic> m) =>
      m.map((k, v) => MapEntry(k, v.toString()));

  /// Prévenir l'équipe d'une boutique (et le Super Admin).
  static String get _me => FirebaseAuth.instance.currentUser?.uid ?? '';

  static void toStaff({
    required String shopId,
    required String title,
    required String body,
    Map<String, dynamic> data = const {},
  }) {
    Db.addInbox({
      'audience': 'staff',
      'toUid': '',
      'shopId': shopId,
      'fromUid': _me,
      'title': title,
      'body': body,
      'data': _strings({...data, 'audience': 'staff'}),
    }).catchError((_) {});
    _post({
      'action': 'to_staff',
      'shopId': shopId,
      'title': title,
      'body': body,
      'data': _strings({...data, 'audience': 'staff'}),
    });
  }

  /// Prévenir un seul membre de l'équipe (discussion attribuée / transférée).
  static void toMember({
    required String uid,
    required String shopId,
    required String title,
    required String body,
    Map<String, dynamic> data = const {},
  }) {
    if (uid.isEmpty) return;
    Db.addInbox({
      'audience': 'member',
      'toUid': uid,
      'shopId': shopId,
      'fromUid': _me,
      'title': title,
      'body': body,
      'data': _strings({...data, 'audience': 'staff'}),
    }).catchError((_) {});
    _post({
      'action': 'to_user',
      'uid': uid,
      'kind': 'messages',
      'title': title,
      'body': body,
      'data': _strings({...data, 'audience': 'staff'}),
    });
  }

  /// Super Admin : donner un nouveau mot de passe à un utilisateur.
  /// Passe par le serveur Cloudflare (lui seul peut modifier un compte).
  /// Renvoie '' si c'est fait, sinon le message d'erreur.
  static Future<String> resetPassword({required String uid, required String password}) async {
    try {
      final url = await _endpoint();
      if (url.isEmpty) {
        return 'Le serveur Cloudflare n\'est pas encore configuré : '
            'la réinitialisation sera possible après sa mise en place.';
      }
      final token = await FirebaseAuth.instance.currentUser?.getIdToken();
      if (token == null) return 'Reconnectez-vous puis réessayez.';
      final res = await http
          .post(Uri.parse(url),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer $token',
              },
              body: jsonEncode({'action': 'reset_password', 'uid': uid, 'password': password}))
          .timeout(const Duration(seconds: 20));
      if (res.statusCode == 200) return '';
      if (res.statusCode == 403) return 'Seul le Super Admin peut réinitialiser un mot de passe.';
      return 'Réinitialisation impossible (${res.statusCode}).';
    } catch (_) {
      return 'Vérifiez votre connexion Internet.';
    }
  }

  /// Faire sonner le(s) téléphone(s) appelé(s), même application fermée.
  /// Le serveur vérifie que l'appelant a le droit d'appeler.
  static void incomingCall({required String callId}) {
    _post({'action': 'incoming_call', 'callId': callId});
  }

  /// Arrêter la sonnerie chez les autres (appel pris, annulé ou terminé).
  static void callEnded({required String callId}) {
    _post({'action': 'call_ended', 'callId': callId});
  }

  /// Prévenir un client (kind : 'orders' ou 'messages', selon ses réglages).
  static void toUser({
    required String uid,
    required String kind,
    required String title,
    required String body,
    Map<String, dynamic> data = const {},
  }) {
    if (uid.isEmpty) return;
    Db.addInbox({
      'audience': 'client',
      'toUid': uid,
      'shopId': '',
      'fromUid': _me,
      'title': title,
      'body': body,
      'data': _strings({...data, 'audience': 'client'}),
    }).catchError((_) {});
    _post({
      'action': 'to_user',
      'uid': uid,
      'kind': kind,
      'title': title,
      'body': body,
      'data': _strings({...data, 'audience': 'client'}),
    });
  }

  /// Nouveautés / promotions : toutes les boutiques (['all']) ou certaines.
  static Future<bool> toShops({
    required List<String> shops,
    required String title,
    required String body,
    Map<String, dynamic> data = const {},
  }) =>
      _post({
        'action': 'to_topic',
        'shops': shops,
        'title': title,
        'body': body,
        'data': _strings({...data, 'audience': 'client'}),
      });
}

/// Réception : jeton du téléphone, abonnements, ouverture au toucher.
class PushService {
  static Session? _session;
  static String _lastSync = '';
  static bool _listening = false;

  static String _topicSafe(String s) =>
      s.replaceAll(RegExp(r'[^a-zA-Z0-9\-_.~%]'), '_');

  /// À appeler quand la session change (connexion, boutique, rôle, réglages).
  static Future<void> sync(Session s) async {
    _session = s;
    final p = s.user?.notif;
    final key = [
      s.uid,
      s.clientShopId,
      s.isSuper,
      s.staff?.shopId ?? '',
      s.staff?.active ?? false,
      p?.promos ?? true,
    ].join('|');
    if (key == _lastSync) return;
    _lastSync = key;
    try {
      final fm = FirebaseMessaging.instance;
      await fm.requestPermission();
      final token = await fm.getToken();
      if (token != null) await _saveToken(s.uid, token);
      if (!_listening) {
        _listening = true;
        fm.onTokenRefresh.listen((t) {
          final uid = FirebaseAuth.instance.currentUser?.uid;
          if (uid != null) _saveToken(uid, t);
        });
        FirebaseMessaging.onMessage.listen(_onForeground);
        FirebaseMessaging.onMessageOpenedApp.listen(_open);
        final initial = await fm.getInitialMessage();
        if (initial != null) _open(initial);
      }
      // Abonnements aux sujets
      final promos = p?.promos ?? true;
      final shopTopic = _topicSafe('promos_${s.clientShopId.isEmpty ? 'main' : s.clientShopId}');
      if (promos) {
        await fm.subscribeToTopic('promos_all');
        await fm.subscribeToTopic(shopTopic);
      } else {
        await fm.unsubscribeFromTopic('promos_all');
        await fm.unsubscribeFromTopic(shopTopic);
      }
      if (s.isSuper) await fm.subscribeToTopic('staff_all');
      if (s.isStaff) await fm.subscribeToTopic(_topicSafe('staff_${s.staff!.shopId}'));
    } catch (_) {
      // Notifications indisponibles sur cet appareil : on continue sans.
    }
  }

  /// À la déconnexion : ne plus recevoir les notifications de ce compte.
  static Future<void> signOut(String uid) async {
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null) {
        await Db.users.doc(uid).set({
          'fcmTokens': FieldValue.arrayRemove([token])
        }, SetOptions(merge: true));
      }
      await FirebaseMessaging.instance.deleteToken();
    } catch (_) {}
    _lastSync = '';
  }

  static Future<void> _saveToken(String uid, String token) =>
      Db.users.doc(uid).set({
        'fcmTokens': FieldValue.arrayUnion([token])
      }, SetOptions(merge: true));

  static void _onForeground(RemoteMessage m) {
    final n = m.notification;
    if (n == null) return;
    if (m.data['from'] == _me) return; // mon propre message
    // Discussion d'équipe déjà ouverte : pas de bandeau.
    if (m.data['type'] == 'team' && m.data['chatId'] == openTeamChat) return;
    messengerKey.currentState?.showSnackBar(SnackBar(
      duration: const Duration(seconds: 5),
      content: Text('${n.title ?? ''}\n${n.body ?? ''}'.trim()),
      action: SnackBarAction(label: 'Voir', onPressed: () => _open(m)),
    ));
  }

  static Future<void> _open(RemoteMessage m) => openData(m.data);

  /// Ouvre l'écran lié à une notification (push ou cloche).
  static Future<void> openData(Map<String, dynamic> d) async {
    final nav = navigatorKey.currentState;
    final s = _session;
    if (nav == null || s == null) return;
    final asStaff = d['audience'] == 'staff' && s.canManage;
    switch (d['type']) {
      case 'order':
        final id = d['orderId'] ?? '';
        if (id.isEmpty) return;
        nav.push(MaterialPageRoute(
          builder: (_) => asStaff
              ? AdminOrderDetailScreen(orderId: id, me: s.me)
              : OrderDetailScreen(orderId: id),
        ));
        break;
      case 'chat':
        final id = d['conversationId'] ?? '';
        if (id.isEmpty) return;
        final conv = await Db.conversationStream(id).first;
        if (conv == null) return;
        nav.push(MaterialPageRoute(
          builder: (_) => ChatScreen(
            conversationId: id,
            createIfMissing: const {},
            title: asStaff
                ? conv.clientName
                : (conv.isOrder ? 'Commande #${conv.orderNumber}' : conv.title),
            subtitle: asStaff && conv.isOrder ? 'Commande #${conv.orderNumber}' : null,
            asShop: asStaff,
            me: s.me,
            shopId: conv.shopId,
            orderId: conv.orderId,
            clientPhone: asStaff ? conv.clientPhone : '',
          ),
        ));
        break;
      case 'team':
        final id = d['chatId'] ?? '';
        if (id.isEmpty || !s.canManage) return;
        nav.push(MaterialPageRoute(builder: (_) => TeamChatScreen(chatId: id)));
        break;
      case 'promo':
        final itemId = d['itemId'] ?? '';
        if (itemId.isEmpty) return;
        final item = await Db.catalogItem(itemId);
        final ctx = navigatorKey.currentContext;
        if (item != null && ctx != null && ctx.mounted) openItem(ctx, item);
        break;
    }
  }
}
