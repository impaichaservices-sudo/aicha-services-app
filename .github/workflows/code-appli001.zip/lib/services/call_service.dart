import 'dart:async';

import 'package:aicha_media/aicha_media.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import '../nav.dart';
import '../screens/call_screen.dart';
import 'db.dart';
import 'session.dart';

/// Appels audio par internet entre un client et l'équipe d'une boutique.
///
/// calls/{id} : callerId, callerName, callerRole ('client' | 'shop'),
///   clientId, clientName, shopId, conversationId, status
///   ('ringing' | 'accepted' | 'ended' | 'declined' | 'missed'),
///   answeredBy, answeredByName, offer, answer, createdAt
/// calls/{id}/candidates/{x} : from ('caller' | 'callee'), candidate…
class CallService {
  static final _fs = FirebaseFirestore.instance;
  static CollectionReference<Map<String, dynamic>> get calls =>
      _fs.collection('calls');

  /// L'appel en cours (un seul à la fois).
  static ActiveCall? current;

  // ---------- Appels entrants ----------
  static StreamSubscription? _incomingSub;
  static String _watchKey = '';
  static final Set<String> _shown = {};

  /// À appeler à chaque mise à jour de la session.
  static void watch(Session s) {
    final String key;
    Query<Map<String, dynamic>> q;
    if (s.isSuper) {
      key = 'super_${s.uid}';
      q = calls
          .where('status', isEqualTo: 'ringing')
          .where('callerRole', isEqualTo: 'client');
    } else if (s.isStaff) {
      key = 'staff_${s.uid}_${s.staff!.shopId}';
      q = calls
          .where('shopId', isEqualTo: s.staff!.shopId)
          .where('status', isEqualTo: 'ringing')
          .where('callerRole', isEqualTo: 'client');
    } else {
      key = 'client_${s.uid}';
      q = calls
          .where('clientId', isEqualTo: s.uid)
          .where('status', isEqualTo: 'ringing')
          .where('callerRole', isEqualTo: 'shop');
    }
    if (key == _watchKey) return;
    _watchKey = key;
    _incomingSub?.cancel();
    final me = s.me;
    final myName = s.canManage ? s.teamName(s.staff?.shopId ?? 'main') : me.name;
    _incomingSub = q.snapshots().listen((snap) {
      for (final d in snap.docs) {
        final data = d.data();
        if (data['callerId'] == s.uid) continue;
        if (_shown.contains(d.id) || current != null) continue;
        final at = data['createdAt'];
        if (at is Timestamp &&
            DateTime.now().difference(at.toDate()) > const Duration(seconds: 60)) {
          continue;
        }
        _shown.add(d.id);
        _showIncoming(d.id, data, me.uid, myName);
      }
    }, onError: (_) {});
  }

  static void stopWatching() {
    _incomingSub?.cancel();
    _incomingSub = null;
    _watchKey = '';
  }

  static void _showIncoming(
      String id, Map<String, dynamic> data, String myUid, String myName) {
    final nav = navigatorKey.currentState;
    if (nav == null) return;
    AichaMedia.ring();
    nav.push(MaterialPageRoute(
      fullscreenDialog: true,
      builder: (_) => CallScreen.incoming(
        callId: id,
        otherName: (data['callerName'] ?? 'Appel') as String,
        myUid: myUid,
        myName: myName,
      ),
    ));
  }

  // ---------- Lancer un appel ----------
  static Future<ActiveCall> start({
    required String myUid,
    required String myName,
    required bool asShop,
    required String shopId,
    required String conversationId,
    required Map<String, dynamic> createIfMissing,
    required String otherName,
  }) async {
    var clientId = asShop ? (createIfMissing['clientId'] ?? '') as String : myUid;
    var clientName = asShop ? otherName : myName;
    if (asShop && clientId.isEmpty) {
      final c = await Db.conversations.doc(conversationId).get();
      clientId = (c.data()?['clientId'] ?? '') as String;
      clientName = (c.data()?['clientName'] ?? otherName) as String;
    }
    if (clientId.isEmpty) throw Exception('Client introuvable.');
    final ref = calls.doc();
    final call = ActiveCall._(ref, isCaller: true, myUid: myUid, myName: myName)
      ..otherName = otherName
      ..conversationId = conversationId
      ..createIfMissing = createIfMissing
      ..asShop = asShop;
    current = call;
    try {
      await call._open();
      final offer = await call._pc!.createOffer({'offerToReceiveAudio': true});
      await call._pc!.setLocalDescription(offer);
      await ref.set({
        'callerId': myUid,
        'callerName': myName,
        'callerRole': asShop ? 'shop' : 'client',
        'clientId': clientId,
        'clientName': clientName,
        'shopId': shopId,
        'conversationId': conversationId,
        'status': 'ringing',
        'offer': {'sdp': offer.sdp, 'type': offer.type},
        'createdAt': FieldValue.serverTimestamp(),
      });
      call._docReady();
      call._listen();
      call._timeout = Timer(const Duration(seconds: 45), () {
        if (call.state.value == CallState.ringing) call._finish('missed');
      });
    } catch (e) {
      await call._cleanup();
      rethrow;
    }
    return call;
  }

  /// Décrocher un appel entrant.
  static Future<ActiveCall?> answer(
      String callId, String myUid, String myName) async {
    final ref = calls.doc(callId);
    final ok = await _fs.runTransaction<bool>((t) async {
      final d = await t.get(ref);
      if (d.data()?['status'] != 'ringing') return false;
      t.update(ref, {
        'status': 'accepted',
        'answeredBy': myUid,
        'answeredByName': myName,
        'answeredAt': FieldValue.serverTimestamp(),
      });
      return true;
    });
    if (!ok) return null;
    final snap = await ref.get();
    final data = snap.data() ?? {};
    final call = ActiveCall._(ref, isCaller: false, myUid: myUid, myName: myName)
      ..otherName = (data['callerName'] ?? '') as String;
    current = call;
    try {
      await call._open();
      final offer = data['offer'] as Map<String, dynamic>;
      await call._pc!.setRemoteDescription(
          RTCSessionDescription(offer['sdp'] as String, offer['type'] as String));
      final answer = await call._pc!.createAnswer({'offerToReceiveAudio': true});
      await call._pc!.setLocalDescription(answer);
      await ref.update({'answer': {'sdp': answer.sdp, 'type': answer.type}});
      call._docReady();
      call._listen();
      call.state.value = CallState.connecting;
    } catch (e) {
      await call._finish('ended');
      rethrow;
    }
    return call;
  }

  static Future<void> decline(String callId) async {
    await AichaMedia.stopRing();
    try {
      await calls.doc(callId).update({'status': 'declined'});
    } catch (_) {}
  }

  /// Serveurs pour traverser les réseaux (STUN gratuit de Google + TURN
  /// optionnel enregistré dans settings/shop : turnUrl, turnUser, turnPass).
  static Future<List<Map<String, dynamic>>> _iceServers() async {
    final servers = <Map<String, dynamic>>[
      {
        'urls': [
          'stun:stun.l.google.com:19302',
          'stun:stun1.l.google.com:19302',
        ]
      },
    ];
    try {
      final s = (await Db.settingsDoc.get()).data() ?? {};
      final url = (s['turnUrl'] ?? '') as String;
      if (url.isNotEmpty) {
        servers.add({
          'urls': url.split(',').map((e) => e.trim()).toList(),
          'username': (s['turnUser'] ?? '') as String,
          'credential': (s['turnPass'] ?? '') as String,
        });
      }
    } catch (_) {}
    return servers;
  }
}

enum CallState { ringing, connecting, connected, ended }

class ActiveCall {
  final DocumentReference<Map<String, dynamic>> ref;
  final bool isCaller;
  final String myUid;
  final String myName;
  String otherName = '';
  String conversationId = '';
  Map<String, dynamic> createIfMissing = const {};
  bool asShop = false;

  final state = ValueNotifier<CallState>(CallState.ringing);
  final ended = ValueNotifier<String>(''); // raison de fin
  DateTime? connectedAt;
  bool muted = false;
  bool speaker = false;

  RTCPeerConnection? _pc;
  MediaStream? _local;
  StreamSubscription? _docSub;
  StreamSubscription? _candSub;
  Timer? _timeout;
  bool _ready = false;
  bool _remoteSet = false;
  final List<RTCIceCandidate> _pendingOut = [];
  final List<RTCIceCandidate> _pendingIn = [];
  bool _closed = false;

  ActiveCall._(this.ref,
      {required this.isCaller, required this.myUid, required this.myName});

  String get _side => isCaller ? 'caller' : 'callee';

  Future<void> _open() async {
    _local = await navigator.mediaDevices
        .getUserMedia({'audio': true, 'video': false});
    _pc = await createPeerConnection({
      'iceServers': await CallService._iceServers(),
      'sdpSemantics': 'unified-plan',
    });
    for (final t in _local!.getAudioTracks()) {
      await _pc!.addTrack(t, _local!);
    }
    _pc!.onIceCandidate = (c) {
      if (c.candidate == null) return;
      if (_ready) {
        _sendCandidate(c);
      } else {
        _pendingOut.add(c);
      }
    };
    _pc!.onConnectionState = (s) {
      if (s == RTCPeerConnectionState.RTCPeerConnectionStateConnected) {
        connectedAt ??= DateTime.now();
        state.value = CallState.connected;
        Helper.setSpeakerphoneOn(speaker);
      } else if (s == RTCPeerConnectionState.RTCPeerConnectionStateFailed) {
        _finish('ended', reason: 'Connexion impossible');
      }
    };
  }

  void _docReady() {
    _ready = true;
    for (final c in _pendingOut) {
      _sendCandidate(c);
    }
    _pendingOut.clear();
  }

  void _sendCandidate(RTCIceCandidate c) {
    ref.collection('candidates').add({
      'from': _side,
      'candidate': c.candidate,
      'sdpMid': c.sdpMid,
      'sdpMLineIndex': c.sdpMLineIndex,
    }).catchError((_) => ref);
  }

  void _listen() {
    _docSub = ref.snapshots().listen((d) async {
      final data = d.data();
      if (data == null) return;
      final status = data['status'];
      if (isCaller && status == 'accepted' && !_remoteSet && data['answer'] != null) {
        final a = data['answer'] as Map<String, dynamic>;
        _remoteSet = true;
        _timeout?.cancel();
        otherName = (data['answeredByName'] ?? otherName) as String;
        state.value = CallState.connecting;
        await _pc?.setRemoteDescription(
            RTCSessionDescription(a['sdp'] as String, a['type'] as String));
        for (final c in _pendingIn) {
          await _pc?.addCandidate(c);
        }
        _pendingIn.clear();
      }
      if (!isCaller && !_remoteSet) {
        _remoteSet = true;
      }
      if (status == 'declined') {
        _finish('declined', reason: 'Appel refusé', write: false);
      } else if (status == 'ended' || status == 'missed') {
        _finish(status as String,
            reason: status == 'missed' ? 'Pas de réponse' : 'Appel terminé',
            write: false);
      }
    });
    _candSub = ref
        .collection('candidates')
        .where('from', isEqualTo: isCaller ? 'callee' : 'caller')
        .snapshots()
        .listen((snap) async {
      for (final ch in snap.docChanges) {
        if (ch.type != DocumentChangeType.added) continue;
        final m = ch.doc.data() ?? {};
        final c = RTCIceCandidate(m['candidate'] as String?,
            m['sdpMid'] as String?, (m['sdpMLineIndex'] as num?)?.toInt());
        if (_remoteSet || !isCaller) {
          try {
            await _pc?.addCandidate(c);
          } catch (_) {}
        } else {
          _pendingIn.add(c);
        }
      }
    });
  }

  void toggleMute() {
    muted = !muted;
    for (final t in _local?.getAudioTracks() ?? const <MediaStreamTrack>[]) {
      t.enabled = !muted;
    }
  }

  void toggleSpeaker() {
    speaker = !speaker;
    Helper.setSpeakerphoneOn(speaker);
  }

  Future<void> hangUp() => _finish(
      state.value == CallState.ringing && isCaller ? 'missed' : 'ended',
      reason: 'Appel terminé');

  Future<void> _finish(String status, {String reason = '', bool write = true}) async {
    if (_closed) return;
    _closed = true;
    _timeout?.cancel();
    final d = connectedAt == null ? null : DateTime.now().difference(connectedAt!);
    if (write) {
      try {
        await ref.update({'status': status, 'endedAt': FieldValue.serverTimestamp()});
      } catch (_) {}
    }
    // Trace dans la discussion (écrite par l'appelant seulement).
    if (isCaller && conversationId.isNotEmpty) {
      final text = d != null
          ? '📞 Appel terminé (${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')})'
          : status == 'declined'
              ? '📞 Appel refusé'
              : '📞 Appel manqué';
      try {
        await Db.sendMessage(
          conversationId: conversationId,
          createIfMissing: createIfMissing,
          senderId: myUid,
          senderRole: asShop ? 'shop' : 'client',
          senderName: myName,
          text: text,
          type: 'system',
          notify: d == null,
        );
      } catch (_) {}
    }
    ended.value = reason.isEmpty ? 'Appel terminé' : reason;
    state.value = CallState.ended;
    await _cleanup();
  }

  Future<void> _cleanup() async {
    _closed = true;
    _timeout?.cancel();
    await _docSub?.cancel();
    await _candSub?.cancel();
    try {
      for (final t in _local?.getTracks() ?? const <MediaStreamTrack>[]) {
        await t.stop();
      }
      await _local?.dispose();
    } catch (_) {}
    try {
      await _pc?.close();
    } catch (_) {}
    _pc = null;
    _local = null;
    if (CallService.current == this) CallService.current = null;
  }
}
